from .utils import checks
from discord.ext import commands
from cogs.utils.dataIO import dataIO
from __main__ import send_cmd_help
import discord
import re
import os

class SetRoles:
    def __init__(self, bot):
        self.bot = bot

    async def _set_role(self, ctx, roleName):
        user = ctx.message.author
        server = ctx.message.server
        role = discord.utils.get(server.roles, name=roleName)

        if role is None:
            await self.bot.say('{} role doesn\'t exist'.format(roleName))
        elif role in ctx.message.author.roles:
            await self.bot.remove_roles(user, discord.utils.get(server.roles, id=role.id))
            await self.bot.say('You already own this role. It\'s now removed.')
        else:
            try:
                await self.bot.add_roles(user, discord.utils.get(server.roles, id=role.id))
                await self.bot.say('{} role has been added!'.format(roleName))
            except:
                pass
    @commands.group(pass_context=True, no_pm=True)
    async def xb(self, ctx):
        """Add a XB role"""
        await self._set_role(ctx, 'XB')

    @commands.group(pass_context=True, no_pm=True)
    async def ps(self, ctx):
        """Add a PS role"""
        await self._set_role(ctx, 'PS')

    @commands.group(pass_context=True, no_pm=True)
    async def pc(self, ctx):
        """Add a PC role"""
        await self._set_role(ctx, 'PC')

def setup(bot):
    n = SetRoles(bot)
    bot.add_cog(n)
