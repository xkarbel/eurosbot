from .utils import checks
from discord.ext import commands
from cogs.utils.dataIO import dataIO
from __main__ import send_cmd_help
import discord
import re
import os

class Euros:
    def __init__(self, bot):
        self.bot = bot

    @commands.group(pass_context=True, no_pm=True)
    async def roster(self, ctx):
        """Gets clan roster"""
        twitch = "   [<:twitch:410463786663804938>](https://twitch.tv/"
        youtube = "   [<:youtube:410463847204388892>](https://youtube.com/"
        twitter = "   [<:twitter:410463666312577024>](https://twitter.com/"
        youtubeshort = "   [<:y:410463847204388892>](https://goo.gl/"

        embed = discord.Embed(title="Euros Clan Roster", colour=discord.Colour(0x358edb), url="https://www.bungie.net/en/ClanV2/Chat?groupId=1901299")

        embed.add_field(name="Founder:", value=("Its Wami" + twitch + "itswami" + ")" + youtube + "w1wami" + ")" + twitter + "itswamii" + ")" + "\n"
                                                "\u200b"), inline=False)
        embed.add_field(name="Team Manager:", value=("Khosla03\n"
                                                     "\u200b"), inline=False)
        embed.add_field(name="Members: (1/4)", value=(""
            "Its GShark" + twitch + "itsgshark" + ")" + youtube + "channel/UCSp_8-o4OJoqhXTnssEYqaA" + ")" + "\n"
            "Octavarium\n"
            "Vsmmario" + youtube + "vsmmario" + ")" + "\n"
            "Mighty Edwinn" + twitch + "mightyedwinn" + ")" + youtube + "Solaarize" + ")" + "\n"
            "Chris Kaizer" + twitch + "chris_kaizer" + ")" + youtube + "channel/UChVSEMP9HCbG3Y2b7GMdcdQ" + ")" + twitter + "TTVChris_Kaizer" + ")" + "\n"
            "The Jew Himself" + twitch + "the_jew_himself" + ")" + youtube + "channel/UCjmvXC3IR2RauMDSj-DSQqg" + ")" + twitter + "Zachary32339053" + ")" + "\n"
            "Moneyshot Chain\n"
            "Living Hurts" + twitter + "jumpandbake" + ")" + "\n"
            ""), inline=False)
        await self.bot.say(embed=embed)

        embed = discord.Embed(colour=discord.Colour(0x358edb))
        embed.add_field(name="Members: (2/4)", value=(""
            "lH o v a" + twitch + "lhova" + ")" + youtube + "channel/UCBN40uKQM49aUHY2cMnCXmQ" + ")" + "\n"
            "TheNamelsSlash\n"
            "Murphsican\n"
            "EenMark\n"
            "Wakkas Flakkas\n"
            "Scrub" + twitch + "xiscrubix" + ")" + youtube + "Scrubonyoutube" + ")" + twitter + "LMScrub" + ")" + "\n"
            "Cruelty" + twitch + "ItsCruelty" + ")" + youtube + "cruelty" + ")" + twitter + "crueltyit" + ")" + "\n"
            "Solid" + twitter + "craig_021" + ")" + "\n"
            "Virsputin" + youtube + "xIAMBIGTIMEx" + ")" + twitter + "Virsputin" + ")" + "\n"
            "Jazz" + twitch + "FidelFLACastro" + ")" + twitter + "FidelFLACastro" + ")" + "\n"
            ""), inline=False)
        await self.bot.say(embed=embed)

        embed = discord.Embed(colour=discord.Colour(0x358edb))
        embed.add_field(name="Members: (3/4)", value=(""
            "GTQ" + twitch + "scuf" + ")" + youtubeshort + "naCbCn" + ")" + twitter + "AdvurtsGTQ" + ")" + "\n"
            "Lumpy LIama" + twitch + "callmellama" + ")" + youtube + "channel/UCSd9rhwNajMv8dSJq2OHqEA" + ")" + twitter + "callmellamaa" + ")" + "\n"
            "Chumyz" + twitter + "JustChumyz" + ")" + "\n"
            "Textbook1987" + youtube + "chadthornburg" + ")" + twitter + "Textbook1987" + ")" + "\n"
            "Ouch MS" + twitch + "ouchms" + ")" + youtube + "ouchms" + ")" + twitter + "ouchmyscapula" + ")" + "\n"
            #"rickyanks13" + twitch + "rickyank13 " + ")" + youtube + "channel/UCFkyaHydKdE3q-FIIA4NGWg" + ")" + "\n"
            ""), inline=False)
        await self.bot.say(embed=embed)

        embed = discord.Embed(colour=discord.Colour(0x358edb))
        embed.add_field(name="Members: (4/4)", value=(""
            "rickyanks13" + twitch + "rickyank13 " + ")" + youtube + "channel/UCFkyaHydKdE3q-FIIA4NGWg" + ")" + "\n"
            ""), inline=False)
        await self.bot.say(embed=embed)


def setup(bot):
    n = Euros(bot)
    bot.add_cog(n)
#" + twitch + "" + ")" + youtube + "" + ")" + twitter + "" + ")" + "
