class ImgurClientError(Exception):
    def __init__(self, error_message, status_code=None):
        self.status_code = status_code
        self.error_message = error_message

    def __str__(self):
        if self.status_code:
            return "(%s) %s" % (self.status_code, self.error_message)
        else:
            return self.error_message


class ImgurClientRateLimitError(Exception):
    def __str__(self):
            return 'Rate-limit exceeded!'
