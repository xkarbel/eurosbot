# -*- coding: utf-8 -*-
from ._version import VERSION as __version__
