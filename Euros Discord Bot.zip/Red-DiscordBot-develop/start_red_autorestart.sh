cd "$(dirname "$0")"
"/usr/bin/python3" launcher.py --start --auto-restart
read -rsp $'Press enter to continue...\n'