cd "$(dirname "$0")"
"/usr/bin/python3" launcher.py